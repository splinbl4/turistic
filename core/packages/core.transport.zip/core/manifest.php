<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd9e7a2c02d5cacbce40d60d7a0e98ff1',
      'native_key' => 'core',
      'filename' => 'modNamespace/8d4617565260bc432ac67059c299e404.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => 'f93a3d8565abe45640c9652e4ea83dd9',
      'native_key' => 1,
      'filename' => 'modWorkspace/63e44f71ec6c71b4dd21b254dbcacded.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'ede6d955c66948d0ba591f809f4d1a7f',
      'native_key' => 1,
      'filename' => 'modTransportProvider/db8559af9af4b03290d0dbecc294d2be.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6d38770844689d56b6d4ef4a745d5d4f',
      'native_key' => 'topnav',
      'filename' => 'modMenu/e94c4600d45efe87a976bdc37acb87f1.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '10bcb255ac18d9a72c428efe89199090',
      'native_key' => 'usernav',
      'filename' => 'modMenu/a26a0bc3511b61785bf97992e5fcf1db.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '69fef13fc2894e2acaf940627c7a1ba5',
      'native_key' => 1,
      'filename' => 'modContentType/e88563c15797e519c665079cececaded.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '13d45cc4046dc6ac857abd2fb54b5719',
      'native_key' => 2,
      'filename' => 'modContentType/92eb3ad9f08a1ea2a3f5f5933944c202.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'da13caa55362608038952ef764eb120f',
      'native_key' => 3,
      'filename' => 'modContentType/b70c97f3f0b6f357a265b1c0f79318b1.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'e4a1c4f026660e187638f5fd100a217c',
      'native_key' => 4,
      'filename' => 'modContentType/399a01ff908a35a17e62d3e320636efb.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '03b7b98127d6622c5963226d3bf19827',
      'native_key' => 5,
      'filename' => 'modContentType/ddb93d7d235b9dd2c172ee9c6645f12d.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b7d7a49eb98e5971e4635253b6a6827d',
      'native_key' => 6,
      'filename' => 'modContentType/5faa9a9e3e94a3ebdbcd67204ef74c61.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '905b2483005fbe01aecf5716cd788306',
      'native_key' => 7,
      'filename' => 'modContentType/e0f3469c766fd2676f04453abe417d8c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '06717e963e46fad2cecdeb2dc097576b',
      'native_key' => 8,
      'filename' => 'modContentType/84d68a94f1509d401f853abcd0c0ed45.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9e7679d50b6940acf63aaeae1f9f6fda',
      'native_key' => NULL,
      'filename' => 'modClassMap/b49bfb87b1de865b671fc256c412352f.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2784b44bf94a91bfc022e539269f2a4f',
      'native_key' => NULL,
      'filename' => 'modClassMap/61dbb51004f1a6e5572c3096e5ab4f1b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '43a968d1fd8e18d3ffef0289dff1c724',
      'native_key' => NULL,
      'filename' => 'modClassMap/ed1ca4ffb9deb60d6804b6ebcc28b9cd.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8fecfb94b006203124e885929397d2f1',
      'native_key' => NULL,
      'filename' => 'modClassMap/f19d9f02d870186eddac5b8526d3b096.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd6751fd80a794367cb176a2fd8f0d4f6',
      'native_key' => NULL,
      'filename' => 'modClassMap/b9be57761491a56a642690f3001e45bd.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '38aa86fba86773676de1338c9919971b',
      'native_key' => NULL,
      'filename' => 'modClassMap/427785b8ebf23e3fbb446fbecb393cf0.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8eca3c57cf11f2df070277f7c2ec092b',
      'native_key' => NULL,
      'filename' => 'modClassMap/fdc14e96982586bb5d77059b41a223cc.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '20442f8d451b5b68c030a0d11ad37164',
      'native_key' => NULL,
      'filename' => 'modClassMap/1ac2a33e93de2d6c8b58f4ad03c27ee2.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5b584267d6fc421262f0177855125b40',
      'native_key' => NULL,
      'filename' => 'modClassMap/2118cda24bc26074d79053938c406008.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1fb7ef615cf3963f86eec665803995a',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/adc8100183a93654fcc9b73f60246dc9.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e6efe4710ff39b80d5cbc3d01dec57b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/c4a0f2fdc30ae9a43b2696d606018b47.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0c8466a6679ec5b53214833d612cefb',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/4b968dfbdd21498d2245b1232d7d8b52.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c48e21285c3176427b009d57fdc618af',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/85cd19e9c0480b8d8f687aa485630976.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93642729eef7a8e65f52a5f2c64e0b7c',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/c597b92b0a8e561f2330b1d6e8ac1b44.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0eaa4917c2ea1cfe086320e73165f032',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/65a2a0f370b58ec39af321ac02e27cd1.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f3c26f870d523605f9ed976d9b7f244',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/0ff1b4ff45fd6004b681f2087bc4d188.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc859b6e954947d50f24bfdefc9d7bce',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/18eded2767266a9ef9e46bb9c5f3c5cf.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e546fde09f51dba3442826a1871b0c49',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/a40137dc1d99b744e30a6a3dfd4eff1e.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d99c47a1a10200e444d278fd3ab8c8d',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/13ac1a965dda2ffc5b74b38ce78137e3.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7b4a6c3fb482a5f54dead71e448d98b',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6712b9051dc67c8e0f13d89dca876238.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1683e78f0a30a5a253365025d3ad1a46',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/de4754519f6022f29c8f45d29a1d7aa8.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef955b24450d70de33a95cb2a182ee9d',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/9280f4baeeb8da9a618af3e1425584e9.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1309ea1ee1733b18264ea7aebcf5dc76',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/1ebc0e40096610f9fef127d4bc017919.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf4a44c92ce5ea437459a3878faaa21a',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/463c79755725a993594385bbc5518362.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d8e29ab92774b1496f333d22c75cd8b',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/76597896b7b8fc4bf7dc02e0b4371307.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2fb67986139038068c4b53b94095ecf',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/1c18171c6e43f949a403e23f6a765396.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4741712ef3d910f9a69b5d10ee3a7949',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/63b13a1fa03847fa24ac32f164a265c1.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '294c869e56d30f8548c3d721078e171b',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/f1e36b540269de215f30a7561f545d98.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78e3e979b4213531f82df89a53af2efb',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/285c7713a358d93cd41bab21beb4e093.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '500a183851a084e4f2cb5bbfeae36001',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/5045a654f96a540c4f058326fb62b4f5.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f081c946c9a012753243907cf76c1384',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/47631d8dc9a35e757a9f38d4ac433425.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd54f9be2351b13087672ceaa42e334b9',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/441c72d5c6abb3421abcb090518b106c.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6eb3a826f355483b3d47eb0b445d75ee',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/4d86fef0dd8bf907bbbbfbb255f32c2f.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbb22f7237f852aa078c2e5f4cdd0e53',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/528735d070888204822a199c94bb846b.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44ead7dd3fa4fdf3d8b5a925a0d54e9c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/307bbc92b27259366424284c14522db6.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b6e7f87e4f9144a59c647919f6c0ecd',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/3291cb661fe7c94839ab364ea41499f4.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e76bea7b01a73fea907418e0726f0ad',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/6b6264ae469d3538d9a55b61dd9cbae5.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2c1b0c37c216fc840394fc0f0f5f662',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/52ec44128cb565a83e8f28f7a19872a2.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'def51e4cb47ef66c44cab9368ed52327',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/ec7305ec10cc873645fc883c63e76573.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '773cf8d5b58f9f9d21d176520131df3d',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/5c95d9f101b275d948dbc925502166b1.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44d3d7b1b0467005e4ffe0f91b5f1470',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/57b03222b363b7313719bb960389d7b5.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85d8eb7a032041ab6965ed47c49ceb37',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/914c34907bbb6225d53dd06099dea859.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '478748bada488717dd08521408fec6fe',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/bf852a2cfe3a029a2cb8b9a29dbac482.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9078517d3f4af94865e125907f679fed',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/99d1791d09001a6703a04045b86d8e84.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5159960531d0d071b644d811d8656f12',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/6c28ce2a999f4d57d3fc4a300e7d84c8.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8198b9a4aeb0ced10a5e3b9495eeb3de',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/39a225abee969481ea763dac447cc0bb.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ff3b709ca6c9a7e3b24e9bbbed56a09',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/863e0b65459cd51738822dbcec5a6d97.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b273748b65d0055d68fbef74b7176c25',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/f48eccc4991446deebc4fce6d13a3db2.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a3ce894c19353de02a4ba404e3d83c3',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/be31970a959d2ba1b8c0d8dfb092bed6.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f76890661a00fd39cd2f60d6351a77d3',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/13eab6bccc12125df75fd6066609a4af.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b849815de8ad49d3d0bcd1bec6dad45',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/019db542bc576cb3a6b93b99327a3dae.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbc790baf96344d36ec032dfb7ffee36',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/fe0caabe8407326efd669872970f29e9.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb23954ea9493c06da39a6c19e1ce72c',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/063cfc04bb35db80a809a3e5baa3baaa.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7da93c6bf669bcd495742e7f3a479f30',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/5f8a203c376a56d544e24aaa2fb05db0.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '432ba47856e419989f16bd286f2f7fc1',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/b164980f63b13d5a5c2ea1e485001d1b.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e1b0e2b3065dae4a271c7ab1f86e0a3',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/7d4574680aad34c2e85f050379d5f134.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2453ab80d14f74cc53893c4df3ebb51d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/7d412cc82fc9197d2e9ff962957c0060.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5a0816e855d810c9dcc7083602f5fe0',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/b617ac977e0078ddcbb99c0c4ddfa138.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd27cd923bf73ff0349a0b8640648197e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/bb015c136a9b8c4722907b9687027e8f.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8316ebfb2f07a5921034068944eac16',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/295b35fb7f1f5ef27831986ee1b1862c.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bdfdb9067dcabb5b740d22389168c15',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/67b80b76a89476bb4f6ae75a3e504828.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae90746a8adda2b11dba4e23c4ac2ad7',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/901b9d16ab6bca1426b4459e6b9496c7.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a0ae12a237a815ced6b1a3217ed7272',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/c8b5ae49736cd117cdabc2b3fbb3fa00.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b4a918fa66d6d168b6644ee3db76193d',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/89fc3f7b03b12c5aa65712011acf6b79.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94d4c196ac68ade6c5c74f8a3a046444',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/28ccc291895b6706f1ad1a924ed9d5d6.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15d885f6a171478c830d8449b981ab54',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/af8e972444de6396d9e508ad57d86d54.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '286eecce9df9fd4e87b242ed0485c85e',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/fc1036688530b436ba4e3cc1f5250030.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71221671fc42540882486e539ebb857c',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/c63317223fad4bbb3a75a0b1ce847c9a.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d42553049ce1395220323fdaa6ae2c7',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/f86e5e83dbfa9b727d2156db35667249.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57d32bcb50f50b74bec6f669ecea1922',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/4d62d2171f3e8042c331f74f5f2f871c.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd87b67f499fc053b6b6e67698094fd5e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/9920eb654bd59dab5ed57e68b849dade.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6e3ed3ec4254f3e4452100275d42882',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/bc22a953c0db8256a8cd2522318b0bc8.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '89c8d751005295131729669bac3bb275',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/20a2d1066b335836d77be5afcfb2fe26.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56e7db9bc1daaade6f21e50e3b3f7ab1',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/0206a1e0b270dba3d8fc59eb7c0bfa9d.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '301c025322be0f4fc373f09372146344',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/6b2310e3ee43eb317d06db0c333c514a.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9d5451831ebcb85a74b6f967dbd84a3',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/733ee36da2b930eb2cf46f2203bd5037.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c48c56f37b2360f9b13bde385292756c',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/e307124d75ddd74e1862472e7f0a98e0.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a244fedece8c08d0a86f88a6bb9cf78',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/8e8bc911d90f5c3010b3d37bd2754d81.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6de7ab911ec09c4f8d868a0bed9367a',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/d6422cdda5ec320357894f6313ffd016.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1092257a1ce90317caae9358d1e3b903',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/8b43065f72d0159719ba30a3a9e3cc20.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74c9a710a93166c671ccc001cb35a01d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/289547ad3b31b5af304cd07992ab291b.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a837f706a2d643b29ea31fddd000321f',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/1972d5e9d7eff68b17acf89fb4822e31.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ee282febdc48c238e222bbb29220cf3',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/d19a709b3c66e97b6d94ab207fe9b635.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f3a08b3970c90cf4c9ff338e1480d2c',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/5e3b92ebcfc5f01db58b1e2ab10ec7ca.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a566dd611ee6dfe7589813f1bb4c5648',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/a8575ecda5b79a811c2bea9ffda6870d.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43dce84d15c19b776a466a80664a16dd',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/6f6f5ab960990fc8a78db3b44cd86d52.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '863dd55ff572ecabaa59eb09a2166358',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/f9c229a30bfcfd08621cd59a33906e24.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df5751716e32c85aaa0280103eca72aa',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/33f99889c85797ff4957e64d4a460421.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df10313dab64a7b6f0c371a17a61d10a',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/7971e57a0eff41365e0f1518dbdf3e2e.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76b345619db533c91ffdb689b1aa711c',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/5ec763c8bec52850923d1fc760a2ad86.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd2b9bb45062ff9d42185671d962e672',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/b6f53e62adc88cace83e9a4a9afc0f6e.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bdc978dcc40a494cb694927a128e6c5',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/4fdef16c8b015253ff4f8d0cc825448f.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f3bd71811172575a095d4a708b33287',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/4f470f84dba16600f735e5b95b9129ec.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb00c24a4e87791092bd56a108e5e22d',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/f8988d62d12e346b0f1520ebb9649a2c.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ec5977975a446aa3fa8a7ae794ce157',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/23d39cf9c565c9d28e91593801935747.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93eeee5415aef46041ea02ee2c180b26',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/6812161878331ef3747b5bf070d10928.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91ca2720e35ad128fbc2dbbcb3f5fa8b',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/952cec935e80be55d0364fdbfd9b14fd.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '866b7c98a1f061e7e1f78a29467414eb',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/c1dcb8c301e0e9c3325e1c3f72caf119.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84eae46153d95d97cbf47d06cfb816d5',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/8816683b594614e30106d7aadee8a691.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fef7f6f6bb9d44b9c3a3dced4cacb2b7',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/56edd76968ab05be855f56d9258f7699.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '622d3c02e0ba6f6c67a6f7dbe315a969',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/948e31fa1dcefa49cfcf8f2be950e810.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '331fe4c7fc63d59759c99441931f3282',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/e360afc69c8daf99c555011c9b890dbe.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '440f315b5b8b0832e3fabf401b90cb48',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/d095741c7716709b298ac145e5dff1f7.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7a44baf4b8e3a224bedce4d5b745a13',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/b458b37b96b88487f374ab9160b6f2e3.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33344e1ba0df04251e219b2520132f5f',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/f20b447c670bd8015113531388760e3f.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef5615ac017f42afc9ad3ec0a4a7ad7a',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/2c837a1c1c7a5734ebe89f178b839150.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1b8fa0b1635c651f0c8b9e5290119bd',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/34b7faf5c5e2e483eebe14f8d09cb6e3.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6213ad0b024875f7846cd0a206f9326c',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c4eb5a5a3001c94b6b8195b92bb9f44f.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a8ffa94985b7a8e4a3d78c51fe30353',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/4bb589937b1c204838f99403ec64e142.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40693878bef01a32d9e5e42ac7e9d6f8',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/362f5fa5eab1a52a3fe09f786d373ffd.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35722ac51718b139bd5bfdd05599032a',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/bc0bc6ab178273f0426f52bc642791c0.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80e7db397cb833651f9b6cbb7475e2e0',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/c2223c2f3029fea56325d1893d714aed.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ca05167f34b0131e7f3585cc1400dd0',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/cbe934b9bc3033b2f2171a1b7dbc76c4.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2d7eae3b1ccc958957bbc9ef11aaba3',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/793c488a9207fbbc9f1ee9e934b9e87e.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd6faa9e10ac342490e7ccb753ad608c',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/697c5e8b78a8eaedfa60a3f021d4f550.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4cb5374e7e054edd96e708b87645bc5',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/1ecb07a25ea0393c14ee52ee7172165a.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca9dae7907711b6633747fed24204889',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/9a7b51466b4319a0cab84642955938be.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2076d00bd33b5b475441c541197e52e',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/63481f66eb2470a52dfcdd692270604f.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f54d7bf286d6ab65111c9c227efcb282',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/d8ceeec6d0911590f068880e1b91948d.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '247cd9d526af6d3f643e476b2e2ee757',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/658c4e5e8768fa40737b1edcd3567e4e.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0496e262cf3300900bf3a9dd68cbc193',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/70da514462cc468d8d49f7244177f115.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75cff0a98ef1f47c7c74aca5464ea8f7',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/b1ec21db130459f4a3cebe1fa23579b9.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6130fe01557a7a3d9ae13f126021fbe7',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/eea77c837587dc3317cfae171a8ace58.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7126cba856d2f95ec8edab71be9fb14',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/88bd5c94ac00629a48a4d277742206ff.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9c46a57b1431ceb111bd72bf64e029a',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/db2a1bdc12d876d6b84f5c9cfc3ddeec.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '855c12d98de07456e5e78554dd1f9f5c',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/15e62eaf0d92d308fc2960a12bb5a685.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34ad11a962fa9298c5b935639d0a84f2',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/770fa6d8938b78b6ed719019745d514c.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f62e94e94e681d00fe979906205d2713',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/db332f75fe2daf38db1cf412b5bb255f.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c35c758e1ce06f1fd03b88d03657ed2',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/359929490fe7fa9b869aac48cb5e7df2.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6eb86f41d94b4eae56b4c72f65557cc6',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/a25f0beece412046bb09621a66a179de.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '947054231b070be7b7429e0549b7d7b0',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/e5821e6947d6c9e9eabafbbfccbdb681.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7213c3e52a2f557bf710bac80f29023d',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/619e3a5e61e5bf15efae3b5e014889ff.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fdd4369de33960c7f5aef7f8f362758',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/76bb6301e3471bf827e7b6283d5297ee.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c681765ab080e9cc32b6917e95dee89',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/af317b8b6ef78c38f00b73f57b55a8bc.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5290069728e9edf49d4a74f74b6f6d6d',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/c53b0a79e2c72fce5865969b34c60f38.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ee95fc2004f3669cd7dcadb78087ec6',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/3ba937078b813fcca7e4a42c0ff8fef7.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e896e8c36cc6da6cd3f0fbe4bb162fdc',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/3551cbcb3029cf384fa0f4a33a96a486.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '159441e9a5f368a2833e4f8d94d22ba9',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/4d4bf8bef736bb54e7fe835377c65b2b.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db1fec191670bc073605796877f0fcf5',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/776158edd3420503b708ae0347377e24.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6e2d6e7d4029e6fcf960a88f6a957c3',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/dd4ac2c791d9f6bcbc008957c09d2027.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e81012df572d4616cf61eb06ed01db4',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/3d37078af919424065b2d8cda996d375.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '875b5c3419e5f60e4b8d607aa731c5ab',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/d28b2b4e6d602c49dc6969551b9c4dbd.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49f4a832691d38efdf443ee43492d47d',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/45ef4070fcc654d1e4059316f38839b8.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '660a3145a828bc13e5431a5ae4105ab7',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/8345dc3af411c602c3cdc7b49003475c.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb09e92c6edcabb94fcd7702afd0d854',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/a1a556298132e2e2acd330c396ada2b9.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dab79ada9d41da13f828a56f20be37b',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2916524acce818cabf889b7b775c6692.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e7b569227c2e5b1f5ba6b4926d0c5fb',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/34d3f0894d46a2a9d5bf65bfc9b2c0e6.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '275a35204c34861a122633f632c7b6a5',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/ccda6be3c597c41692cc5a9b8e4bb954.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '88fbe16c46fdfb3faacc62478fed3e1c',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/9d5300001007c29312cd5c5b1d995c0d.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bdece5e015d2cc512278e9af7f9a394',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/1e630cd7751d4192d3dc982c133fea0d.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f867019f1b541eee62c34deb54771ca',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/9315c9b78d21ff5277cb7fc8546510b3.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a413aea41aa6c558357e65ae6c167b8',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/6106dcfc5b24ae03a5edc054924418a7.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a788f92acda02d23bd3ed75155eadac2',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/ece74154f2a049bf356fadd9d741d2b6.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61b09e46be63e711b79cd8f41d129408',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/5a282e38d23dd91b4e7b3978f3122d53.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '458ae057f3986fbf8f7e38b06375f749',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/e7b8a6eeafa6b17e5c56fee5dcae1274.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8537732c5469692e0c68b0cf54a0bde3',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/d5f44a37fbb2709cc7b035768a0869f0.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5db9d94f2e63084e182d156d9f37d08',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/f53561fad3febe4bec9f47246a525eb1.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9fcf7aa606b0a2ddd15b0208401acca',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/387c812f8b4c684719df75041f3d6434.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c321907aa63412b1ea279ca33ec7db0b',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/c165292b6cddb85d847baf4fe9cddaae.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eab869d0884b1b2dbc95abb0e4680e9b',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/fc5af9682251b90409e7974ff30a1e11.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09be8d2bd3a08f6798908df3eeecc0ba',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/9ae964b37bb8af057724491c9b13f85a.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02fe674ad568e7e7bb7d3c927cd3cf80',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/fcd30682f68212e00cee49baae47607e.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e13c86f7adbb5099d859b261f21e5e2',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/2cba974d850aa811a3ad23c688493c3c.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a709aee89199ae5396df8c18d35d3924',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/b3c6c1d4c6743ed2754594e1a39508bb.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f96d550c6a378357104b377b90aa1452',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/16944becacd7c662d67e284058f86eb6.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1f53fad7ef225fbb1960719fe976a06',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/46addf3895d51539e65e608219d4defb.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffca18c1441dc50641d92f238836d8db',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/d37b095e5ea44d6cf7c88985f251cebf.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '714dc69fc6e7e7c6e498470a10eb17f6',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/05e471dd0f9abf1c3808a6557c5b10a1.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abfb962c968aa31379b16da9b80c9a84',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/d6de3e53ab7bac566b61c3cd4b6f4520.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33ca07898862f534f30e52cb1fa219b7',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/d0bdcdbbfe04ae4f141e7f83103d06e8.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80e8e40f0dc4e94caf289cab0b0f7237',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/9701550e6dfce6d4d4ac537f141f64bf.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6ad6507229f80a30ccb6018a13d1d9c',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/458a95a6f5248ab3be0b09979e30c95e.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66402b3b1806f752612460a63ac8a8b6',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/0e6fd20b5f9f72875c9a6ff27d8bec6b.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dbfba90b2517d41806d45a0e53ea281',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/2f69714a1f6d3528c1010349e2dad26c.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b033a94cdae0175f389c49205f791f7d',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/359c8a014514ceeae78125982df48371.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc8a980549d645eaae003892fefe10c7',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/4931d8328997474d0d4c23f8a8905f0c.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '566b268b66bc9a050944715e38280589',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/48c7269606334c9e65e091e44a3e035e.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55b20f9a69c820c563db9bcd98231d6d',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/5750cb576a99a1b9506e052f734dbfd5.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac5babe8210337cf695a10fa3616261c',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/55e270eb830219e120d6e06f545210f4.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba41e028c22fcb2a5e096d255efebbd2',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/458591fbee33eb0276a57723f7b12dfd.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14df147efd7bfc96b0ba2997f64b8c15',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/5eacf6d47b6067d80d96cee8a014e8c5.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be50cb464395a41053801ad9e146d04c',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/ccfc81ca30339854b6e219ee16ffc926.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '722ddcd213489c165b2c5c7524297248',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/94f6b0b3b5397e5cd9642805ca0a17cd.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f0dde034daa8c93826055b24b224ded',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/715982df7b751d06db2db19a3282efbb.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '388885636c598d8d79ffc020c83a39bf',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/bd00a5f1090709149fc0b7b3540155ef.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2c4e3c57629a025c3a98f6618de80f9',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/077dd57bd5b3758aaf4f2d82d1ba51ee.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b86592130243b3570cac330381a0f3ff',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/fde49d8fbd4757a15e23ce3186f45d36.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e600a53820152bc5c103a68e276fde24',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/1b7838d7650e0ae29bb9c296c0f72cbd.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1fed1d5ed8868ab446a171da195fc802',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/0666ab43ea06df5c639c351cbc0e077c.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d2fd54282e8954905f20660da68193a',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/0afdc4f02b68bb955023f00b2251beaa.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20b536b446c8aa5b1a3ad45fd81aac3a',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/486e67099e89783f4ea084c40dcfbbc7.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27678f6b79234eebc3ca3f99b8c9eb5e',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/df79275655a22d7671df32a0e958bdba.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fc79e1cea6bba60312d0d958b795a00',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/fbb176bb4c784587583248f4a05be189.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '672c6be0d4c48aa1122d930a5cfed943',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/f98cc40e11cbbcec514a0ea4bed936c5.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c483617bfb4d4d8ce3835e5edf11aaf7',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/bdfc524dd04947ab1ba99d5c262f1026.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2cd4fcf18a4105664d791905274e332',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/752400909df6061426a7ee58c8b79f3d.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a595941231974fe0078897259abff04e',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/6a70fbd9e72d1b92e83a3c7736090283.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70d0819c21a4dbf53e2176093b9c9d4b',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/123fc85a1d3b4513a886be6d432f8553.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '389d84e666de83ac50190194881e649a',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/6b7d1fd47c1c429fa02a4cc7e6920c1f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9167a789d36df8db2519da7b1c7700b8',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/8626b3b5f188f23b025381abd20f23a8.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b82d73544501181fa11534097a58f40',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/3688fc3f81dd78b6f9ff1fac1df48ca5.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13be725d123e6ddc55f455233b7f1d6a',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/ddb94f2ec19c618ca1434da531ba84f1.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c58beb306a5f362d7b31706e334830e',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/c22f0fb9588663dd85df5ba933227969.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9761cb648227db416212879dab40eca5',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/b0e5d9e02bd755f4c657844497ec0bfb.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b47f450da09b3a6657a049f717b968f',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/b8807255d7cfaf2d6b318ff0bec0bda0.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3e5cde8befe0a10e60aa449e64a7328',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/914b26429dadd713a86126877cc4cc27.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1c0781cfa67d3ec7205f8f14689a01f',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/f259ccdba10e1045721bf98ffa4e48d7.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8c7910112213b3a5bcae1da06f93462',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/8f6e8a6c505e2c3e8d111257a13230c9.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f417aadd2630cd802a9546da0a27c5d',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/0ff4c5552aebd197aa1e51787e4d886a.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f306e978a26008406f70f840cfd5bf12',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/f006f8a7b4d09b9139d58125dc749379.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a946838e57ef682a3be603b85f134d99',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/50b0416dbdb03a709653b63f1c058a59.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6849e9b3c5bd5191addc9c5e617a7177',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/8c8b2103108366ad47bdea5134cca8bd.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be0e7774797b977bbdf781aee63a445b',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/ecb7096aa5c6d0f80a10fe06b3b42a3d.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee65c90d1874c4e35853e674a7c26455',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/8e84dfcf9e562c04261a339e0275c884.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca9cebb4802760cdbdf062040544bdb3',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/dbd34f08572824199404bcccc48d539e.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bbb26c4814b5f1913064869f81f5d0f',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/add373db9d4efe5c41a4b081a939ffd8.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37f23f6365cfb997ac9724f717e0c462',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/2df24392409a968abdb3f4e70d06ea2a.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ddc0ff893803642c40761f84377a9a7',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/82d03de435398204762457e9819a5886.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2608a0f5e9fd0008098df04090b6fcba',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/e984c874b2af78b53f9ccbb342603ce1.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af5d465074d91c93823f614a39573fe6',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/c7d857aeed87d6b53eb75735586fdbdc.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4875ed4d8fdda9fc14008c0c2ae66df8',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/e0ea75c91b385089179c6a882e6e730f.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e3498e5e0bc5ca66b5f09707ddb86cf',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/d5d710ec8c1efcba684e6f13928751ca.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4875d6d0f6b8de435c2619f2e5ac1c62',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/99a954119dd060dab18769ac2039c5a0.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad5855ca6cfd34c8fae276421d99deba',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/1ebb55e3467e5b595070b3f1ea47b3aa.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41acbe56e94804f4931ebf9f0c94016e',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/1906b90aec517323fa024d3cc352b17d.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c0f2b922dd718f2d665154eb3b202bf',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/46cce711937c854a870abaf9eccd5846.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5654b4c94e2ef484ce6679c20b68476',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/84920cfebb01b79af4dbcd43f5c6a304.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '311e7936ec16270c87d67f2f12f2fdef',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/b8a547e43bcc38e9abc6c7bcf86ddb62.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1519e2dc679d104844e7795b13693c7',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/198faf95a9fc79bc8fd99aa71d0cace0.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99473bf36d8ab5faf2da83660c7db1f4',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/2bc11c2dc3d445acacadcab4cba72faa.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '701da9269115387561df1d18d1a77c43',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/e90f6df6173afb9418a796c8d209ed98.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '426d944d0a6e2117dc20d9dd45a73ac3',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/cd6bdaab790a1d3315a760bd1f83462e.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9567f6062994c3c83666e967e5dda11c',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/643e69311b52211949adba5112016390.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c21815285e2617aa16ecdc6f3e26527e',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/9b18000884462b092cae3dafabca4362.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0aeab4ec5d7b084177c276cfc5a8236',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/68c9f864a1a9b2eb33163a1587421bfc.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e859c3a1e50777ec5e820bd89043f826',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/22f1c6099c1fd20a7430438f3f595573.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf537d2d58ceaaaabd93d3bbd3785daf',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/d2cf914e3d5cc8831896e21b455d6100.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3187d60c375dfdc68271214104682581',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/f597c5af873f70e003bb006046717540.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f49869802b729e43d1ed30e934517d83',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/28285dd18c30f86f3a9b63e49c691fe0.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f43fc25e009a2970f2a98560ee0ea03',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/9cbe25bc2af4db727e6cdb40603a2ca7.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '708185ff1314742fff98a6616cf6019f',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/61384f4e1096da61fd116718b65c36d6.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2ca37cad5f1a2adafe55b42cb552421',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/55562846b059f97bcec1a48ba4f29e91.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aee760e385d561d1fac3655cb4b1e138',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9313ce4cbcc29ca11dd5ae1a6253f7bd.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b30a02d28670202941c3b3545a19d517',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/ac0e3f8246f8578ee6bdc98b764299e6.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac2fe71c17d44c48c2e25fbd90e60552',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/d2ee22909f5666bb0011b4cca5a83654.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de55d9cc120d31296b37455b1f5b82b5',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/ab311014e8299710491f98d4275a6473.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18edde75f1f5eeb1ae28c0821857f824',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/baacfc685caa563c314736a98083989b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '059fb980f06324624a76fc44031586bc',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/aab7aefea3df85d2d5dfe8a5101d4ed6.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37e0e5d7f51957ece189bccd342d15a1',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/82ce13114e2851f4c4eeedd853d496b4.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce21461ad2d5c323d2866a7e43aad5cb',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/3ca02871504772ad89d18b25d1c0a625.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83627f77dd86228a5640b99d772ada0a',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/96cd24fe53407f3f84b6ab14c6d90bf3.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '114983301c40109c0fa58f70bfd8a1e2',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/43984b8e6d311843621da8502b9902ce.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8a290718fe5a45d984fcd747e8fd44f',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/2e42d50c0a269da6a89588646df37165.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08d44b39cae90b22c3d7a011fd15d96b',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/efd59365a929998892beb037f51af406.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '717e77ccb00fe2cdb3f40c69a8756ed2',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/fe48dd20a523e313dce6bf0fa6e12513.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2af05aa9e510b824614b385bbddfc7e5',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/5215c5fe6a29c4dcab7dbe5fcc8581bf.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cb6f26d60ebfb9c21d5c12092fd3ee5',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/e48e4e6f7965024331198c6421c862d6.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32107a9458af4cfc5ca2660748974f49',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c055181544ebaff4ff9bcb8b323c4859.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d93c3f7c668d8567efe8341d3dbcc7b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/b3de4285feabc278cb785237d2aee304.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b1d2ade579361d9034dcbf83074afc9',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/2a02d7f877261a6f7bfeed1043b4546e.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11e7becebfa27cfb2cb8990f50a122dc',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/28ef1e3e764fa3029bd583102b6dc823.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e9d8eb17adf6db88f2db05bb4fecc36',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/573e4f0af22750d8bfad612cd15fee3b.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca4c16abcf5a7e2a14e999eeb801758c',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/a4483921fbe5470076f22575d6cd0b58.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5372e8bd8652fe16d1c73ee082936f78',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/2e4666240ad1149971b6c3d3e76cf96a.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b36810892bc7e5edd745227c0acd5d2b',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/ed2cc0a156df16317d1475c22c5dc257.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34895b75415fe802e8efbe4dd8c5d3e7',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/6f192534ae935277525c1e18176194fd.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbcf0dd53cb0c2d36f1eda8b518c9d5c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/d7a0a3b3f0290e9d31fd627c907a3d92.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e63f77801551dcf521c6e512cdb67e',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/eaa8a4351932e2cda693aa97d660f882.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67b935eb3d7829562286b52d397dd7a3',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/54cdd1e60b8ad2585f21e7e1a110c9ad.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c260dc870942e1fa3816b4caf143349a',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/3a704c897676a3258f3a7dc751ca9ba6.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9080d48e36940b76b6db5273fce273ff',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/7111b6445ac3faff65f88e45923e39d4.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6acb6358ee223a440bfd58dfe2854552',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/7c94b335daf5c6d197086cc4433feb3c.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e70421ed2076981fd33f100174bad0a9',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/3902e9386bec07f3ad1cd878182a52e4.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9cbe5852c1dc47e240369187a318ae',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/8967958985da48aa4ec935b337f700c8.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a94adbd1ac45b22f9f512347599d872',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/f0905c1ca5906828e31fb47e19c26cf2.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fff466d18420b3d2e1961b5d1198b8a',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/64de1a8590303b5e22d5a504decee348.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd06218294fd874cf7949f06feb689983',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/d959d95bf42263fb2f309021c9006a91.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd86579cfae1d17426a59f3d819cc7ec2',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/2579a1ec823fd82be02eafbb0bc117ba.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14dd5da00b041bdcdbf647c74e9d58bf',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/9d86fbd9a205977c7d71b1741a21cf62.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2250e31b587f9c032a44d0770334e89a',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/b36c046dc6f63b163f8553d99231139a.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4261fe406d164e9a2270d49ff64177d3',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/91e8cfe03d66eca0ff5dd2671b9189fb.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8f744f750afc873449571c367d50b9e',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/f0eef2ec0890d89ea2396c73b604bf8e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28d4ad7709fdc89313c064d2a293c16b',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/cabd4aa5f0145f83afd5a5110c4b6cb7.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b1140f7777985a2917f9811e558fe6c',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/d38d91b9e6098ecd742b7707c4acf43a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7217c0dd9ca70772b04cbb180dc5842',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/dfdc6d390311ffb21e48d24653a3a729.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '859bc4355b4845505e07e5c796932d80',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/5013471d939db9d90aa8e13af6d2c9ea.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5b5f9df8a66575d952826f2923e799d',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/3b8e5d8139dce4871635e037be3f3514.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c50bdc23721c3eb96a03a9e68c479064',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/145f6c9cca25238294a61ff396d43250.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '198b9d91e867444e1f8126ecc5bf53cb',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/0e7ed80b2adf087fe3c4fcd960372b26.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4717cb055fb80257232185e3895eb9a4',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/b23991e93d1aa6e1f86af5bdb8ea78b4.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c35c54d35948a539087ca40a9b04a56b',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/ddc77b0b4986100cc45811ff2e9a2696.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8461b4b839d090ff2763463eddd3066',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/d8ac1d977266b447fd8943fd2dcd15b0.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9712a3e8eaef665a88168bb0538f8e4',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/f80877d26d2a238fe93b7e5ca0c19d18.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8574f64e7e03d81fb3fcb272a89fc3f7',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/d56ea9179e45ca1fd2d59e484021e885.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '603391820368c9c150e22d861d48b692',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/d9f392ad0fedc7c3bf1e7040282148e9.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51edea5e8102ddaf51e2102aaab32050',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/3547bb0075dbd919cf1770340f04854b.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3456d6318cd48f029d413e8a140aa98e',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/d92e9c4807849438adba3e29437ffd3d.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dea270180c3bf79fe380712cfe5fe7c',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/af4d9720aefe1a8762bda82d619c8494.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60d133ca96fb321ce247d86b2fa64a47',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/19a8541efc578e47b77fe5f5df9d6e87.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'babfd3c1e60ad70152e7ac863a1ba24b',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/faa277633e7e3df029cabbd6400ff319.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35124b8ff051f6bf55446a066475a8af',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/6a4b55eb6977b37a50525c7e1bab9b2b.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '784452f0c4ff9de408db38dbc8009a24',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/c32960144ebb253101e7b73389d9d543.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f9dc5cbcb2dbfcf2c151e8d97baf56a',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/921562952efdcdfb7417380697425a16.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaf5032548526f9d4393464314ead6a5',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/168ed196d659f0b2340103cf3e3eb18c.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9ff7ef04dcda1564226c3b2dcac0d57',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/52d0ce78b81c603e88c9f563ce5234da.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a01f17e8b1aa2581137190e6ac6e75c',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/dcf32c977b98b128e57bf5e901289777.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c73383e1db2fe6b006d122608751bce6',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/28cd1cbd9df1dc4fd05db2536c0dfbcf.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2ba5024021463313fb4eea252d44a41',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/93aec03e8ac2d20bf1412596fc5d6c0f.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efc74284ebe4aac0ba1f12bb713e9e78',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/9d47eafea8e03bc601ea6194bff22e28.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08f02563317af0644741b50901b831fa',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/97a1b5a5b3bddece15c2591e496e59c9.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e11f50bcc6924799db9cde6ab479e92e',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/69f90a3d25f5b8fbcadf9463c3171da3.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '019686c55c6bb45356204af616b9b710',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/92812c6e26dd61523ee184ec24693d15.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a9b08acb16e12adc2ef67887456adca',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/8270e7741ca25df5ec27e6bb8e91e9a6.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81a508d0eeaae26997d86d32c5f97c79',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/e70d43368cb9431e0295283ae1072a8b.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a94cb8a32f69f6a710b1bab9ffccdb1',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/54c0427e0fafcfc17ef6a679e7f935c5.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e3daea4c2bea0a1ab0728bd719c82e5',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/4fb9a02c21936cefe5733a45063ad196.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37dffd73dc27d18dd306c46f34c9f823',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/1154b3b5d2a94799aa376a515f8a5b22.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d91c3f1a1a7a2163c638dca03cac4fa',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/c965ea60d9e3fe89381d076b2d9ee222.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a45b57c8fd577c1e92d36a59d9a623c',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/b1ea4054d3857aff7f03911b6037873a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f39a3278db43e558e4115aa66e8b687f',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/43e24dc656bb7e2cf1bd578415acd492.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7eca74d4a10decc47f35a5c43009f1c4',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/d234e82f7581c026df7e317d0130ba5c.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d81aa5022578d0f89cf89e025065aba',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/979e06f6ea704dcc78489c29bf429916.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86011dedd69c89aba0045f4066f4580c',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/88b1d4de89cef2a46dc650b2020aa127.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0215ab246b9f4f92536458218afd9f7d',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/13b42925a5ed93e3020752fec9bace89.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74d7fe73f4e545de21280b755f10929c',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/1224f052070ee85bedef597da0e20488.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a62bebe0a263acacb7008dcbe8e116fa',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/0a0dff280c47d47eb982fb34c614ee44.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b4969b4df39c8dd3a50036ef62761eb',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/013c30411b9d75581c96966869c5c334.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5497ebe624c5b916f8b759cba502d4cd',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/0b67d8493c9cc9587e190b80b6198a72.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bd23536bf1ba83174f1c5e40ea3eb96',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/d38a34a653d36bbb901fb7515353da9c.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '634f727c7bada485bb5756a712cced60',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/77619e3fde3ccbb08e69052a5405d015.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eea5145bd923127ad7e47eb0c617f528',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/f705d458d66c60833f2543603b3a3cbe.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd90232296bfe7c3ebed7a269e4098c4',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/99a17e09da76ae7afa23aa1eb292ebe6.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04deb60253d0e2c6ee3627896561cb0',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/9e5e8dcb3ef00b07c04c6ad175d97c99.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c63b24d63b468010735ddcb1ee7ab738',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/2d38bbeccee19fcaaab495f8324fd290.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'caebd529494e83611d31dd9ff72b42c1',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/18a6ea6460618800648813bf01e89bdf.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35c7d87bf811e2dfa7d5b4547d4c30a6',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/1fee20897a2584c5117e4da439de752a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56c5a0adbfeda5e53eb9434117d04fc0',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/135c89c39ea321c93b1229fba37f4fb5.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21c2045f3681608aa2dabe7563517177',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/d4d9761fafe4ade5cc0e2c39afa3f197.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '936abac646a7c127b128abc92dd242b1',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/ffd7d75e2c8ea1c75ed111fd297af4dc.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c84f87ff7a02bf10462f065e17d07cf',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/1a7b7e2b20f6c757ead4bc6fd94d8a29.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38dfe48e2ee3b7b1e3554adb47029149',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/024a54d5f14efe0af1490301aebab05e.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3bb2a6863139a280185ec84ff52fe2b',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/dcf1fb2d267cf04da19d95b10e479607.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '709188269d3ffa8ea4c78420013271de',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/9cb05f92d2adf1f3630677d94940211b.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0cb24e61dbd9b000c5d294c0ed0d28',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/50a28e78abbd6b15be578303afe6fcac.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '240ba27e55430d45fcd7825406fac1fe',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/53108323f621f0820983b4aecfc98bf7.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7651ed22807a1d3c8245c3c6bf248716',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/8b1b32249d2571429e5f90a4fa6032d2.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b8a0222de430167c569a7388d90a393',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/660967d7a38059beb70b861f06a32400.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f61ae653c17f704befceafdfa4ca25ed',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/f80c1c45cb6de52c6ab21e4b59d2e3f5.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42518164c5292c39c0a2cefcbbd1459a',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/42de0907be7ef86046e5ee7dbbe756e8.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbfa0fd1c252485cd582d55533303ed0',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/3b767531a00a4981a728f52cf4449962.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e15d55d53de24c24bd5a421fd3ac5c63',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/4e62d7147f77d8715712791ee42ae11f.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83efee27f8026f7853fddaa981b79120',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/15362bace90926d04ee83eadb7defeed.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe8037bebf0db378c3386484cd860c1f',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/9c0fb137ff0026bc3add79b1cdba8e1b.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e3d7125aaa79f6de902073d0d82455',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/2f4dfd2651ac60b422c8c662814ebc9c.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6dbad530ad7370b03337fbf981c2970',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/d971e33d5bcb84f60d8d0c63c1890732.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e84a975c22d1d2a22debe5e475c471e',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/e3b6c00c8e4f8bbeb50f46b42c6800ba.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2c3f85cd534a24be47f135c5f2594ba',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/6761173192080b63020c1c12319e3b56.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17c97e61e5244ccb263c87303654df39',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/6a3af0999d768b0b2d3f351a6a73d92c.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c22802924f64305188da01cd72556f9d',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/4b9404afc4f86e3a9704031353baf739.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40ac25a6ed05b28df81e8c3c7b0463d8',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/346a6f132a312cda32ceebdeb99edfef.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc06baf090060f8bd816f14d933cbb10',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/13925f3c35dc33933dd135bcd674e61d.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fb4e92c7bbd4f3ae47b277f3e5d8271',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/ab6b9a89c7f29169d26d06b4da14c325.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08dcddbd6631e0041c29ef477e3057ff',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/6c9d4d99cae326413b7aa995e513d2d2.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bd7bdea6db0b768b7119393835fc5f3',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/c5c99127eb8ed96ba65c8ab9ef9d6e28.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd3cc1640b586991e894bd0689e65b5',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/ad64046d25d5c2f68685f3c33eb9b127.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e928eaff1718db83c3fd85de52f9490e',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/8829e6b7551fd2e19be3fe97c70652a1.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd805906f3967fd23ebe2c0c29b59a5b9',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/52f6347a73f04fca5c87760790146eb1.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '398b9302bb120607885fc30393227797',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/8c9a33e2bdbc3ca3d541125f234eba34.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa150f5b88f437deb7bd1a709dd4e66a',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/c42ddc8b109d6bf93e0f16170a7eb47e.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd120cbfb250aeb3bfc0c16e81229d34',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/6ed71ec995d452dc4446ea5129d60ac4.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbaad1526068bc6f8d383519363ab90d',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/d8e326d62e67598456a07a244ee5e9b9.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c1e996152715707924b2f75da8db45b',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/23429d156f30e59b468d8477981da613.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d040e08bdc0b65391f2ab41ec57e897',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/adc36258ac86c15fe8346f7264878523.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7f5560e7fc1e78b7ec3f80eef82e793',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/ead65af40a3177d48c994d0a6880b0ac.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55cc85c6e85865ce33ff477a2689a88c',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/6d9eb0cad0672507ef06087363c61b87.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f4b51a663a864e8da7d7163ac95da84',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/52b4268cf6f8988c506e4f0391531118.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55455880670723e66b452c1fe9276fd8',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/7da813d44d1eba211d539fe80b326a17.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1806d905850945a2e0252540fdeec376',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/3eff4e891b74676905c2d74e991736e3.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccaf79a0c8b8582b5975d06b4114aeaa',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/53a0fa7464e0a33eeb6504d8c14a8205.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '715c0735ab8326e5192a9da2e2d96b65',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/5a6f0426e0cf66527acb31eeb0071ef6.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '713ef77502f7c94d494ce1678c86aa74',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/35ee1be325422599eb5edae8e687cbb2.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '571bf0eb05c4bf5546316bc27a35376b',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/5f16565fc940527b56fc0ff2233b5209.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cced30a4be7e8dbc77bcaa0e3942dba9',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/3e5949f67a98efdbed84681be264e726.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02350904ffc002e96e11739e7b27b485',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/5bc30414038655762e2fc397fec2f5fb.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3532473ec4d005205caf481e76652fc8',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/492b77374f217b22f12442268bfc3dac.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04b72653627abd411b7b53cca032b925',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/214d63bb0779f72dc27ffc4c62fbe620.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0aed84ef3abeb300090739d7942b497',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/2274ba929f20c9dc44977af0029899a2.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca8553c5b0fca1e1898c40118d3ab553',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/1673cbd33d3eb1b2b849c91535fdbee0.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aff877029d7e295f5c4919bc1eac2de9',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/26b87ea625346bcbf343fbae77f61851.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9c787baf9f9cbd7c8d88c120be269ea',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/1fb91642529a8d61f6927078c7478bae.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '000c476165bba5d41ba38013923c211e',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/29dfa90dcd23d9768a25399ea09c356c.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9df7ecb20f0a62c08d07f6a6206d43e',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/dd6e12d4a5f823c36a962b2304a4c14e.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b46b18b2eb61d1989946130adade7a0',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/88e5882912101f8a89fafe17d457a83d.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d4b140097bb757a979306033bdfdc8d',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/c799ee9dc7716f97001fc1f90568f2b1.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79741daf270a871c7cdcd340f752b5fe',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/01851a3e54f072bbf4b35db1e570d975.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8fc0f23a38a3bdbaccc14d0e98f3df5',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/fd3c47a84f3fa5e72ba96508803ab43d.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1874608095db31ee5d003583a1552bc9',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/f7b333ee22b9a9f4003898d059f59237.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbe7a7dde6cbe5f5fae28f5ff6c32f4b',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/a3f52c46e4bfce4cfff7d8bd34af1c95.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8a11f836a17cf9c8239d79c315a8f48',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/113b3caff7d0e7e08ea31123653f9570.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3512ba668db89858d448282dbb62def',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/2e8e50d19ca6a91bad8824051aaf4c16.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca594dd02795bf8994b5b539f35ab81',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/d804ee0b5d44b0dc89b711df4e00df0c.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df6c22276fcba1898f9923890cf7ccef',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/b8d36458d73eede1c33e6daa0d0ee880.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8e99e79105b60a9c6b8d3992d53b241',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/4570014e12a99fc39404bd6c190878db.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc63106f4dca23d919062d0637725903',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/8b48255b064d1541a1168c6987108437.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee5aa21360accdaf8d732ed8cf24c752',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/96f8b4d7449450c6578d0dcdf580a81a.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '128735d91d40eb747b9ef0d466c2a289',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/29b917a9e5eabfa68922cf357385782a.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fee66e83c1fd08d449c01a24367bfb43',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/e791b08289323dab5b8ee454d669f0d4.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cb615b01843100879ab2f4e42952767',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/72ec8d36fbed37b76e719ef1343e754e.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5238d6e058b2b1ab05daf212169e9064',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/370594f063d012cd5caa152a40232db3.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5efd0968c3f995d4654181ffc1aa95cc',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/929c65b2363b0e61b64cb68d12f51a90.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b0af3f915106f0ae46bdce4426ac1be',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/3b447ba9e81ba91e4012309c9e58ab55.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea425955a5290a54f9e372e325a4c96',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/3db1de6c2bd0122da203a674d861b969.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1125778c3c4e57d3d81e61bc045316b',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/602163dc58ef1b36fa709bcf5552d6ba.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8832a4a0a901ae1b47c4e4a04b8a5417',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/10618df421a10927dd2621adf8727c94.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b41b8608fcd4637dc292695b31aba33',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/5523499427f1cbc5c5d622c60c1f1035.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f86fe69aec2a47cf62d5d9231f4bc464',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/7e8c36adcbd6501cb9e7548003dc3bb2.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '8d3846d8295a8da77bfe976ddd2a7d36',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/6c59e263d858f7850ecb33bcdaeacba5.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'c0a081b7d2097b8e6989c122401d2979',
      'native_key' => 1,
      'filename' => 'modUserGroup/765481249318b629a882bf1bf709b2f4.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '1e96cdc3742e26c6eaa968f6030a6226',
      'native_key' => 1,
      'filename' => 'modDashboard/642e26112f554a511f6fa737c749f4c2.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'c5f0b19903115cd7c7daf1987db3f92f',
      'native_key' => 1,
      'filename' => 'modMediaSource/e8e7351fb08faef0d5214113b7d0d42f.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '468de754fdc7bd6b06128c18ad466407',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d42b31e7a705110832ea48bfd4165dae.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e4628c1390f5e636c811e5e3475196f3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ea3e454688551bcd4cb1d8dd67c539d7.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '162768fcb1333a48c5ff0abcb9b05971',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/bfa98b5005ecb4157efa0f556125e90d.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '7066b63ddec9365980ff6f74435e1f71',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2076710bf21f0115372cbebe964f9ad1.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ec42f62ba3214d998dff6ea0271da311',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a1986e0652703894155a3fc6b97aad97.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '80b865e1ece60493e70d770c645cad2f',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/89c80aa4acb05171840647513029a631.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '990499b5c6440ad6634b234ced4e7574',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/e88037ed57cee0492837dfc081efcf58.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '476b307f7e58c108aadef98faf09155f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/a36dfc162a90213efb5120faccbe47b7.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '5f509dbd6803c380d9d4b6784a860f68',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/cc8dc857f7279b1498f7baba3167455c.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '97d7bb8203837c459caf1e8671d30b2b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/17bf8c1792c464cc511c1c95c14f689f.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'cdcfb8d0d9e919a845bbf05b35a1b2d8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/29d1c3bd39e1e565c39b527250a27ef9.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd280fa80e920782da1b8c2ff2ea8582c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5ca761c5804b6e4fffb7e23cc327b854.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '72e84becd9a696e2dd6f2456a58b7f4f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7a638a907831bf0be25bf4c44184a335.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '7bd8ec69481ae279321c7fdbda873ed8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d475c0ccb2e2fb6c96ca26814e530be8.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '1cf1c644bfd30f84606a9e593732716d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/06e29cb9e2adb70d85106247a017c7da.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3f1c93977d8f4233d67a43109dfc2097',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2df99e15e2bdda41571d947977f03f1b.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd88a6d2fbf0bbd380a547424b4470ec2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f1dbb607f43aa44471cdbd9f0e097a4e.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '40ffc27cfd1be43ed4d22ec98e9ae155',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cf30f535b1588f051060dea174e1cfaa.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e89e0a383b6e3072c5ce72303c52b936',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8ddd342a8f867e2be7ca7843c369d8da.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6c285f9e37df37b44ded80f60ad5ec97',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ed5820095837ae62c0a313d7d5501af8.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '01a3c0aa8c65a9e2ee1e788c31a45f1c',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/61d5fc273b3c499e21c4ea6a7841f64e.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e74604825088b92d39b8deef3570f1dd',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/89adc109ce35ba2708e090a98175d5f3.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '17199fd6d52e49873aee1de716e356d2',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/384caa848eb795c473df0a2a040e5a80.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5fc3cd7097f26fcdfaaaad34dbfbacbe',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/0a7bca1f9fe34a81cdefb49f3e622b0f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '3a43a37fbc10b024b6884efa8f6f37f5',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/a98c6e3da7f8c485ddb8d6712c540c99.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b213c0e4a0f050061af81d68b9cbf484',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/e3737fca4018c4df1281db8387fb00a7.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5bbf9aad49caf0bde8e81daee5eeb375',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/395e9e9996e55bf6a4c7cb4ebc7d55d2.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '428d720c8047bb45bc1d0d39b991aa10',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/843675b96149faf53a5f027fbe326911.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e7ca03d0bfa1adff6ad194716106e5bc',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/e2e94aa582debb087e4a0dae3f3a95ae.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '84973c59153dc837b6fc2cb9d4c99df7',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/18d2cce14908dc4995cfbe0d14f5cdbd.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '98f7c91ee9b7f4c43e0302e0fe21bbca',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/5ee4605aa9f717609d4637def9c005da.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd52593b740e08c26cdeebe001bc1d699',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/77309f8ba292ed3bd18382ebff805f46.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '260d64bb62666a16d9b583a27c792802',
      'native_key' => 'web',
      'filename' => 'modContext/c79c5146860ac0e805f531706406fd8b.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'a45e7d2e6604aaa2d66b3f7718eeee3b',
      'native_key' => 'mgr',
      'filename' => 'modContext/c22042c8de258646a9712264915a51b0.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1d4591742c324d57d4999c8f6fc2da21',
      'native_key' => '1d4591742c324d57d4999c8f6fc2da21',
      'filename' => 'xPDOFileVehicle/84c96a4767762f993cdb2895105c37b5.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '45959d1759d4fd40623f478688aec27f',
      'native_key' => '45959d1759d4fd40623f478688aec27f',
      'filename' => 'xPDOFileVehicle/1aef7200cff5835d23e6f1dc367520d1.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '23be86ec24c23fbf91c7b811853dd3de',
      'native_key' => '23be86ec24c23fbf91c7b811853dd3de',
      'filename' => 'xPDOFileVehicle/6dbf5ce7c5dda054d815fd4ac10860dd.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f11ba810aec67603bf782af5ae18b5e8',
      'native_key' => 'f11ba810aec67603bf782af5ae18b5e8',
      'filename' => 'xPDOFileVehicle/9588ed3595149920a8271290a514d32d.vehicle',
    ),
  ),
);